//
//  NSMutableArray+Shuffle.h
//  Mini Collector
//
//  Created by Peter Stromberg on 2011-01-09.
//  Copyright 2011 NA. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSMutableArray (ArchUtils_Shuffle)
- (void)shuffle;
@end
